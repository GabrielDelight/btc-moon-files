let email = document.getElementById('email')
let password = document.getElementById('password')
document.getElementById('signinBtn').addEventListener('click', e => {
    if(email.value.trim() == '' || password.value.trim() == '') return alert('All fields are required')
    e.preventDefault()
    console.log('Clicked');
    //var btcmoon_address = $('#btcmoon_addr').val();

    var data = {
        email: email.value,
        password: password.value
    };
    console.log(data)
    var data_stringify = JSON.stringify(data);
    $.ajax({
        "url": "http://localhost//btcmoon_app/API/users/login",
        "type": "POST",
        "data": data_stringify,
        success: function (data) {
            console.log(data);
         var res = $.trim(data.message);
            if (res == "Successful Login") {
              setJWTCookie("jwt", data.jwt, 1);
              setLocalStorage(data.Userdata);
              location.href = "/templates/home.html";
            } else {
              alert(data.message);
            }

            


        }, error: function (err) {
            console.log(err);
        }
    })


});