var jwt = getJWTCookie("jwt").toString();
let userData = JSON.parse(localStorage.getItem('userData'))


var url = new URLSearchParams(location.search);
var paramsid = url.get("userId");

// Getting all followers
let data_stringify = {
    jwt,
    userid: paramsid,
    action: "followers",
}


data_stringify = JSON.stringify(data_stringify)
let appendFollowers = document.getElementById('appendFollowers')

$.ajax({
    "url": "http://localhost//btcmoon_app/API/users/followers_following",
    "type": "POST",
    "data": data_stringify,
    success: function (data) {
        data.map(val => {
            appendFollowers.innerHTML +=
                `<div class="has_relative_user">
            <a href="/templates/profile.html?userId=${val.userid}" class="users_list">
                <img src="http://localhost//btcmoon_app/${val.image}" alt="">
                <div>
                    <h4>${val.name}</h4>
                    <p>@${val.username}</p>
                </div>
            </a>
            <div class="follow_div">
                <button id="followersBtn" class="followBtn">Follow</button>
                <p style="display: none" id="folloingId">${val.userid}</p>
                <p style="display: none" id="followers">${val.followers}</p>
                <p style="display: none" id="following">${val.following}</p>
            </div>
        </div>`

            // Hide my own list 
            let folloingId = document.querySelectorAll('#folloingId')
            for(i = 0; i < folloingId.length; i++){
                if(folloingId[i].textContent == userData.id){
                    folloingId[i].parentElement.parentElement.style.display = 'none'
                }
            }

            // Check if am following any of my followes
            let followers = document.querySelectorAll('#followers')
            for (i = 0; i < followers.length; i++) {
                if (followers[i].textContent.includes(userData.id)) {
                    followers[i].parentElement.children[0].classList = 'followingBtn'
                    followers[i].parentElement.children[0].textContent = 'Unfollow'
                }
            }


            let followersBtn = document.querySelectorAll('#followersBtn')
            for (i = 0; i < followersBtn.length; i++) {
                followersBtn[i].addEventListener('click', (e) => {
                    if (e.target.textContent == 'Follow') {
                        e.target.classList = 'followingBtn'
                        e.target.textContent = 'Unfollow'

                        // Clicking here to unfollow a user
                        let followid = e.target.parentElement.children[1].textContent

                        let followDetails = {
                            jwt: jwt,
                            userid: userData.id,
                            follow_id: followid
                        }
                        console.log(followDetails)
                        followDetails = JSON.stringify(followDetails)

                        $.ajax({
                            "url": `http://localhost//btcmoon_app/API/users/follow`,
                            "type": "POST",
                            "data": followDetails,
                            success: function (data) {
                                console.log(data)

                            }, error: function (err) {
                                console.log(err);
                            }
                        })



                    } else {
                        e.target.classList = 'followBtn'
                        e.target.textContent = 'Follow'
                        console.log('U unfolloed that user')
                        // Clicking here to unfollow a user
                        let unfollowid = e.target.parentElement.children[1].textContent

                        let unfollowDetails = {
                            jwt: jwt,
                            userid: userData.id,
                            unfollow_id: unfollowid
                        }
                        console.log(unfollowDetails)
                        unfollowDetails = JSON.stringify(unfollowDetails)

                        $.ajax({
                            "url": `http://localhost//btcmoon_app/API/users/unfollow`,
                            "type": "POST",
                            "data": unfollowDetails,
                            success: function (data) {
                                console.log(data)

                            }, error: function (err) {
                                console.log(err);
                            }
                        })
                    }
                })
            }
        })

    }, error: function (err) {
        console.log(err);
    }
})
