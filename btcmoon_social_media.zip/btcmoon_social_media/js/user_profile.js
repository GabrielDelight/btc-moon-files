// @ get the user profiles deyails
var url = new URLSearchParams(location.search);
var jwt = getJWTCookie("jwt").toString();
let userData = JSON.parse(localStorage.getItem('userData'))

var url = new URLSearchParams(location.search);
var paramsid = url.get("userId");

let sendProfileDetails = {
    jwt: jwt,
    userid: paramsid,
    action: "user_profile"
}

sendProfileDetails = JSON.stringify(sendProfileDetails)

$.ajax({
    "url": `http://localhost//btcmoon_app/API/users/user-profile`,
    "type": "POST",
    "data": sendProfileDetails,
    success: function (data) {
        console.log(data)
        document.getElementById('userName').textContent = data.name
        document.getElementById('userEmail').textContent = data.email
        document.getElementById('userFollowers').textContent = data.followers_count
        document.getElementById('userFollowings').textContent = data.following_count
        let avatar = document.getElementById('userAvatar')
        console.log(data.user_profile_image)
        if (data.user_profile_image == '' || data.user_profile_image == null) {
            return document.getElementById('userAvatar').src = '/images/avatar.png'
        }
        document.getElementById('userAvatar').src = `http://localhost//btcmoon_app/` + data.user_profile_image

    }, error: function (err) {
        console.log(err);
    }
})



let fetchUserPost = {
    jwt: jwt,
    userid: paramsid,
    action: "user_post",
    viewer_id: userData.id
}

fetchUserPost = JSON.stringify(fetchUserPost)

$.ajax({
    "url": `http://localhost//btcmoon_app/API/users/user-profile`,
    "type": "POST",
    "data": fetchUserPost,
    success: function (data) {
        console.log(data)
        // @ loop with map 
        data.map(val => {
            let imageURL  
            if(val.profile_image == "" || val.profile_image == null){
                imageURL = '/images/avatar.png'
            }else {
                imageURL = `http://localhost//btcmoon_app/${val.profile_image}`
            }
            if (val.post_media_path == '') {
                appendPost.innerHTML +=
                    `<div class="post_container">
                    <div class="view_post_head">
                    <a href="/templates/profile.html?userId=${val.post_author_id}">
                        <img src="${imageURL}" alt="">
                        </a>                    
                    <div>
                    <p></p>
                    <a href="/templates/profile.html?userId=${val.post_author_id}">
                    <p>${val.name}</p>
                    <p style="margin-top: 10px; font-size: 10px">${val.time}</p>
                    </a>
                    </div>

                    <div class="option_icon"> <i class="fa fa-ellipsis-h"></i> </div>
                </div>
                <div class="post_content_container">
                <p>${val.post}</p>
                </div>
                
                <div class="total_reaction_container">
                </div>
                
                <div class="reaction_container">
                <div>
                    <i id="likePost" class="fa fa-heart"></i>
                    <span>${val.like_counts}</span>
                    <p id="likers" style="display: none">${val.likers}</p>
                    <p style="display: none">${val.postid}</p>
                </div>

                <div><i id="" onclick='viewPost(${val.postid})' class="fa fa-comment"></i> <span>${val.comment_counts}</span></div>
                <div><i id="" class="fa fa-share"></i> <span>0</span></div>
                </div>
                </div>`
            } else if (val.post_media_type == 'image/png') {
                appendPost.innerHTML +=
                `<div class="post_container">
                <div class="view_post_head">
                <a href="/templates/profile.html?userId=${val.post_author_id}">
                <img src="${imageURL}" alt="">
                    </a>
                <div>
                <p></p>
                <a href="/templates/profile.html?userId=${val.post_author_id}">
                <p>${val.name}</p>
                <p style="margin-top: 10px; font-size: 10px">${val.time}</p>
                </a>
                </div>
                <div class="option_icon"> <i class="fa fa-ellipsis-h"></i> </div>
            </div>
            <div class="post_content_container">
            <br>
                <img src="http://localhost//btcmoon_app/${val.post_media_path}" alt=""></img>
                <p>${val.post}</p>
                </div>
                
                <div class="total_reaction_container">
                </div>
                
                <div class="reaction_container">
                <div>
                    <i id="likePost" class="fa fa-heart"></i>
                    <span>${val.like_counts}</span>
                    <p id="likers" style="display: none">${val.likers}</p>
                    <p style="display: none">${val.postid}</p>
                </div>

                <div><i id="" onclick='viewPost(${val.postid})' class="fa fa-comment"></i> <span>${val.comment_counts}</span></div>
                <div><i id="" class="fa fa-share"></i> <span>0</span></div>
                </div>
                </div>`
            }
            else if (val.post_media_type == 'video/mp4') {
                appendPost.innerHTML +=
                `<div class="post_container">
                <div class="view_post_head">
                <a href="/templates/profile.html?userId=${val.post_author_id}">
                <img src="${imageURL}" alt="">
                    </a>
                <div>
                <p></p>
                <a href="/templates/profile.html?userId=${val.post_author_id}">
                <p>${val.name}</p>
                <p style="margin-top: 10px; font-size: 10px">${val.time}</p>
                </a>
                </div>
                <div class="option_icon"> <i class="fa fa-ellipsis-h"></i> </div>   
            </div>
            <div class="post_content_container">
                <video src="http://localhost//btcmoon_app/${val.post_media_path}"></video>
                <p>${val.post}</p>
                </div>
                
                <div class="total_reaction_container">
                </div>
                
                <div class="reaction_container">
                <div><i id="likePost" class="fa fa-heart"></i> <span>${val.like_counts}</span></div>
                <div><i id="" class="fa fa-comment"></i> <span>${val.comment_counts}</span></div>
                <div><i id="" class="fa fa-share"></i> <span>0</span></div>
                </div>
                </div>`
            }

            // Auto change all the heart color to gray
            let heartPost = document.querySelectorAll('#likePost')
            heartPost.forEach(heart => {
                heart.style.color = 'gray'
            })


            // @ Check id user like is in the post
            let likePost = document.querySelectorAll('#likers')
            for (i = 0; i < likePost.length; i++) {
                if (likePost[i].textContent.includes(userData.id)) {
                    likePost[i].parentElement.children[0].style.color = 'red'
                }
            }


            // @ Liking this post
            let likeBtn = document.querySelectorAll('#likePost')
            for (i = 0; i < likeBtn.length; i++) {
                // @ Get the color of red If I have already like a post
                let idsArr = likeBtn[i].parentElement.children[2].textContent
                if (!idsArr.includes(userData.id)) {
                    likeBtn[i].style.color = 'gray'
                }else {
                    likeBtn[i].style.color = 'red'
                }

                
                // Addding and unlinking a post
                likeBtn[i].addEventListener('click', e => {
                    let post_id = e.target.parentElement.children[3].textContent
                    

                    if (e.target.style.color == 'gray') {
                        // @Added like
                        console.log('Like a post')
                        let likeDetails = {
                            userid: userData.id,
                            post_id,
                            jwt: jwt,
                            action: 'like'
                        }

                        likeDetails = JSON.stringify(likeDetails)

                        // @ Like a post
                        $.ajax({
                            "url": "http://localhost//btcmoon_app/API/users/like-unlike",
                            "type": "POST",
                            "data": likeDetails,
                            success: function (data) {
                                console.log(data);
                            }, error: function (err) {
                                console.log(err);
                            }
                        })

                        // Change color
                        e.target.style.color = 'red'
                        // Increasing the like count
                        let likeCountVal = parseInt(e.target.parentElement.children[1].textContent)
                        likeCountVal = likeCountVal += 1
                        e.target.parentElement.children[1].textContent = likeCountVal
                        return
                    }

                    else {
                        console.log('UnLike a post')
                        // Unline a post
                        let likeDetails = {
                            userid: userData.id,
                            post_id,
                            jwt: jwt,
                            action: 'unlike'
                        }
                        console.log(likeDetails)

                        likeDetails = JSON.stringify(likeDetails)

                        // Like a post
                        $.ajax({
                            "url": "http://localhost//btcmoon_app/API/users/like-unlike",
                            "type": "POST",
                            "data": likeDetails,
                            success: function (data) {

                            }, error: function (err) {
                                console.log(err);
                            }
                        })
                        e.target.style.color = 'gray'
                        // Decreasing the like count
                        let likeCountVal = parseInt(e.target.parentElement.children[1].textContent)
                        likeCountVal = likeCountVal -= 1
                        e.target.parentElement.children[1].textContent = likeCountVal

                    }


                })
            }

        })


    }, error: function (err) {
        console.log(err);
    }
})


// redirect to view post
function viewPost(id) {
    location.href = "/templates/post.html?postid=" + id
}

document.getElementById('viewFollowing').addEventListener('click', e => {
    location.href = "/templates/following.html?userId=" + paramsid
})

document.getElementById('viewFollowers').addEventListener('click', e => {
    console.log('hello')
    location.href = "/templates/followers.html?userId=" + paramsid
})