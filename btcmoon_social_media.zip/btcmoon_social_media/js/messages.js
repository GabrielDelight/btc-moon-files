// get or read localstorage
function getLocalStorage(arg) {
    var Userdata = localStorage.getItem(arg);
    return JSON.parse(Userdata);

}
let ownerId = getLocalStorage('userData').id

$.ajax({
    "url": `http://localhost//btcmoon_app/API/users/messages/${ownerId}`,
    "type": "GET",
    success: function (data) {
        console.log(data)
        let appendMessages = document.getElementById('appendMessages')
        for (i = 0; i < data.length; i++) {
            appendMessages.innerHTML += `
            <a href="#" onclick='chat();' id="chatAnchor">
             <div class="has_relative">
            <div class="chat_wrapper">
                <img src="/images/img.png" alt="">
                <div>
                    <h5 id="name">${data[i].sender_name}</h5>
                    <input type="hidden" style="opacity:0" id="chatid" value="${data[i].sender_id}">
                 <input type="hidden" style="opacity:0" id="username" value="${data[i].sender_username}">
                    <p>${data[i].message} <span style="font-size: 10px">${data[i].time}</span> </p>
                </div>

                <div class="chat_option">
                    <!-- <i class="fa fa-ellipsis-h"></i> -->
                </div>
                <div class="has_chat_count">
                    <p>10</p>
                </div>
            </div>
        </div>
        </a>
        `;


        }


    }, error: function (err) {
        console.log(err);
    }
})

function chat() {
    var userid = document.getElementById("chatid").value;
    var name = document.getElementById("name").innerText;
    var username = document.getElementById("username").value;
    location.href = "/templates/chat.html?userid=" + userid + "&name=" + name + "&uname=" + username;
}