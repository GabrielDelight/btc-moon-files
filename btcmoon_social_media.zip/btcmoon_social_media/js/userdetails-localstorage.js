
// function to set localStorage
function setLocalStorage(arg) {
  localStorage.setItem("userData", JSON.stringify(arg));
}

//setLocalStorage(result.Userdata);


// get or read localstorage
function getLocalStorage(arg) {
 var Userdata = localStorage.getItem(arg);
 return JSON.parse(Userdata);

}

 //var Userdata = getLocalStorage('userData');
