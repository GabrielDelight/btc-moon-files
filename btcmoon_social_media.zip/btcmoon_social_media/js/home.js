var jwt = getJWTCookie("jwt");
let userData = JSON.parse(localStorage.getItem('userData'))
let inputText = document.getElementById('postInput')
let file = document.getElementById('inputFile')

// previwing image
document.querySelector('#inputFile').addEventListener('change', function () {
    if (this.files) {
        console.log(this.files)
        document.getElementById('previewImg').src = URL.createObjectURL(this.files[0])
        document.getElementById('previewImg').style.display = 'block'
    }
})


// @ Create a post
document.getElementById('createPost').addEventListener('click', e => {
    console.log(file.files[0])
    let formData = new FormData()
    formData.append('jwt', jwt)
    formData.append('post_author_id', userData.id)
    formData.append('post', inputText.value)
    formData.append('post_media', file.files[0])

    // console.log(sendData)

    $.ajax({
        "url": "http://localhost//btcmoon_app/API/users/create_post",
        "type": "POST",
        "data": formData,
        contentType: false,
        processData: false,
        success: function (data) {
            console.log(data);
            location.reload()

        }, error: function (err) {
            console.log(err);
        }
    })
})





// @ Append all post on home page

let sendData = {
    userid: userData.id,
    jwt: jwt.toString()
}
sendData = JSON.stringify(sendData)

let appendPost = document.getElementById('appendPost')

$.ajax({
    "url": "http://localhost//btcmoon_app/API/users/home",
    "type": "POST",
    "data": sendData,
    success: function (data) {
        console.log(data)
        // @ loop with map
        
        
        data.map(val => {
            let imageURL  
            if(val.profile_image == "" || val.profile_image == null){
                imageURL = '/images/avatar.png'
            }else {
                imageURL = `http://localhost//btcmoon_app/${val.profile_image}`
            }
            if (val.post_media_path == '') {
                appendPost.innerHTML +=
                    `<div class="post_container">
                    <div class="view_post_head">
                    <a href="/templates/profile.html?userId=${val.post_author_id}">
                        <img src="${imageURL}" alt="">
                        </a>                    
                    <div>
                    <p></p>
                    <a href="/templates/profile.html?userId=${val.post_author_id}">
                    <p>${val.name}</p>
                    <p style="margin-top: -10px; font-size: 10px">${val.time}</p>
                    </a>
                    </div>

                    <div class="option_icon"> <i class="fa fa-ellipsis-h"></i> </div>
                </div>
                <div class="post_content_container">
                <p>${val.post}</p>
                </div>
                
                <div class="total_reaction_container">
                </div>
                
                <div class="reaction_container">
                <div>
                    <i id="likePost" class="fa fa-heart"></i>
                    <span>${val.like_counts}</span>
                    <p id="likers" style="display: none">${val.likers}</p>
                    <p style="display: none">${val.postid}</p>
                </div>

                <div><i id="" onclick='viewPost(${val.postid})' class="fa fa-comment"></i> <span>${val.comment_counts}</span></div>
                <div><i id="" class="fa fa-share"></i> <span>0</span></div>
                </div>
                </div>`
            } else if (val.post_media_type == 'image/png') {
                appendPost.innerHTML +=
                `<div class="post_container">
                <div class="view_post_head">
                <a href="/templates/profile.html?userId=${val.post_author_id}">
                <img src="${imageURL}" alt="">
                    </a>
                <div>
                <p></p>
                <a href="/templates/profile.html?userId=${val.post_author_id}">
                <p>${val.name}</p>
                <p style="margin-top: -10px; font-size: 10px">${val.time}</p>
                </a>
                </div>
                <div class="option_icon"> <i class="fa fa-ellipsis-h"></i> </div>   
            </div>
            <div class="post_content_container">
                <img src="http://localhost//btcmoon_app/${val.post_media_path}" alt=""></img>
                <p>${val.post}</p>
                </div>
                
                <div class="total_reaction_container">
                </div>
                
                <div class="reaction_container">
                <div>
                    <i id="likePost" class="fa fa-heart"></i>
                    <span>${val.like_counts}</span>
                    <p id="likers" style="display: none">${val.likers}</p>
                    <p style="display: none">${val.postid}</p>
                </div>

                <div><i id="" onclick='viewPost(${val.postid})' class="fa fa-comment"></i> <span>${val.comment_counts}</span></div>
                <div><i id="" class="fa fa-share"></i> <span>0</span></div>
                </div>
                </div>`
            }
            else if (val.post_media_type == 'video/mp4') {
                appendPost.innerHTML +=
                `<div class="post_container">
                <div class="view_post_head">
                <a href="/templates/profile.html?userId=${val.post_author_id}">
                <img src="${imageURL}" alt="">
                    </a>
                <div>
                <p></p>
                <a href="/templates/profile.html?userId=${val.post_author_id}">
                <p>${val.name}</p>
                <p style="margin-top: -10px; font-size: 10px">${val.time}</p>
                </a>
                </div>
                <div class="option_icon"> <i class="fa fa-ellipsis-h"></i> </div>   
            </div>
            <div class="post_content_container">
                <video src="http://localhost//btcmoon_app/${val.post_media_path}"></video>
                <p>${val.post}</p>
                </div>
                
                <div class="total_reaction_container">
                </div>
                
                <div class="reaction_container">
                <div><i id="likePost" class="fa fa-heart"></i> <span>${val.like_counts}</span></div>
                <div><i id="" class="fa fa-comment"></i> <span>${val.comment_counts}</span></div>
                <div><i id="" class="fa fa-share"></i> <span>0</span></div>
                </div>
                </div>`
            }

            // Auto change all the heart color to gray
            let heartPost = document.querySelectorAll('#likePost')
            heartPost.forEach(heart => {
                heart.style.color = 'gray'
            })


            // @ Check id user like is in the post
            let likePost = document.querySelectorAll('#likers')
            for (i = 0; i < likePost.length; i++) {
                if (likePost[i].textContent.includes(userData.id)) {
                    likePost[i].parentElement.children[0].style.color = 'red'
                }
            }


            // @ Liking this post
            let likeBtn = document.querySelectorAll('#likePost')
            for (i = 0; i < likeBtn.length; i++) {
                // @ Get the color of red If I have already like a post
                let idsArr = likeBtn[i].parentElement.children[2].textContent
                if (!idsArr.includes(userData.id)) {
                    likeBtn[i].style.color = 'gray'
                }else {
                    likeBtn[i].style.color = 'red'
                }

                
                // Addding and unlinking a post
                likeBtn[i].addEventListener('click', e => {
                    let post_id = e.target.parentElement.children[3].textContent
                    

                    if (e.target.style.color == 'gray') {
                        // @Added like
                        console.log('Like a post')
                        let likeDetails = {
                            userid: userData.id,
                            post_id,
                            jwt: jwt,
                            action: 'like'
                        }

                        likeDetails = JSON.stringify(likeDetails)

                        // @ Like a post
                        $.ajax({
                            "url": "http://localhost//btcmoon_app/API/users/like-unlike",
                            "type": "POST",
                            "data": likeDetails,
                            success: function (data) {
                                console.log(data);
                            }, error: function (err) {
                                console.log(err);
                            }
                        })

                        // Change color
                        e.target.style.color = 'red'
                        // Increasing the like count
                        let likeCountVal = parseInt(e.target.parentElement.children[1].textContent)
                        likeCountVal = likeCountVal += 1
                        e.target.parentElement.children[1].textContent = likeCountVal
                        return
                    }

                    else {
                        console.log('UnLike a post')
                        // Unline a post
                        let likeDetails = {
                            userid: userData.id,
                            post_id,
                            jwt: jwt,
                            action: 'unlike'
                        }
                        console.log(likeDetails)

                        likeDetails = JSON.stringify(likeDetails)

                        // Like a post
                        $.ajax({
                            "url": "http://localhost//btcmoon_app/API/users/like-unlike",
                            "type": "POST",
                            "data": likeDetails,
                            success: function (data) {

                            }, error: function (err) {
                                console.log(err);
                            }
                        })
                        e.target.style.color = 'gray'
                        // Decreasing the like count
                        let likeCountVal = parseInt(e.target.parentElement.children[1].textContent)
                        likeCountVal = likeCountVal -= 1
                        e.target.parentElement.children[1].textContent = likeCountVal

                    }


                })
            }

        })


    }, error: function (err) {
        console.log(err);
    }
})

// Store userid in this tag <p>
document.getElementById('saveuserId').textContent = userData.id

document.getElementById('viewFollowing').addEventListener('click', e => {
    location.href = "/templates/following.html?userId=" + userData.id
})

document.getElementById('viewFollowers').addEventListener('click', e => {
    console.log('hello')
    location.href = "/templates/followers.html?userId=" + userData.id
})


// redirect to view post
function viewPost(id) {
    location.href = "/templates/post.html?postid=" + id
}


document.getElementById('userProfile').addEventListener('click', e => {
    location.href = "/templates/profile.html?userId=" + userData.id
})


// fetch user profile
let sendProfileDetails = {
    jwt: jwt,
    userid: userData.id,
    action: "user_profile"
}

sendProfileDetails = JSON.stringify(sendProfileDetails)

$.ajax({
    "url": `http://localhost//btcmoon_app/API/users/user-profile`,
    "type": "POST",
    "data": sendProfileDetails,
    success: function (data) {
        document.getElementById('userFollower').textContent = data.followers_count
        document.getElementById('userFollowing').textContent = data.following_count
        let avatar = document.getElementById('userAvatar')
        if (data.user_profile_image == '' || data.user_profile_image == null) {
            return document.getElementById('userAvatar').src = '/images/avatar.png'
        }
        document.getElementById('userAvatar').src = `http://localhost//btcmoon_app/` + data.user_profile_image

    }, error: function (err) {
        console.log(err);
    }
})

