var url = new URLSearchParams(location.search);
var post_id = url.get("postid");
var jwt = getJWTCookie("jwt").toString();
let userData = JSON.parse(localStorage.getItem('userData'))


let postData = {
    post_id,
    jwt
}
postData = JSON.stringify(postData)

$.ajax({
    "url": "http://localhost//btcmoon_app/API/users/post-details",
    "type": "POST",
    "data": postData,
    success: function (data) {
        console.log(data)
        document.getElementById('postOwnerName').textContent = data.author_name
        document.getElementById('timeOfPost').textContent = data.time
        document.getElementById('postText').textContent = data.post
        document.getElementById('commentCounts').textContent = data.post_comment_count
        if (data.post_media_path === "" || data.post_media_path == null) {
            return document.getElementById('postOwnerAvatar').src = '/images/avatar.png'
        }
        document.getElementById('postOwnerAvatar').src = "http://localhost//btcmoon_app/" + data.post_media_path
        console.log(document.getElementById('postOwnerAvatar'))



        if (data.post_media_type == "") {
            document.getElementById('postImage').style.display = 'none'
        } else if (data.post_media_type == "image/png") {
            // @ post image
            document.getElementById('postImage').src = `http://localhost//btcmoon_app/${data.post_media_path}`
        }


        // @ LIKE SSCRIPT*************************************************

        // Get the like length
        let likeArr = data.likers.split(',')
        document.getElementById('likeCount').textContent = likeArr.length


        // @ check If I've liked the post before
        if (data.likers.includes(userData.id)) {
            document.getElementById('likePost').style.color = 'red'
        }


        // @ Reacting to post
        document.getElementById('likePost').addEventListener('click', e => {
            let likersIds = data.likers
            if (!likersIds.includes(userData.id)) {
                let likeDetails = {
                    userid: userData.id,
                    post_id,
                    jwt,
                    action: 'like'
                }
                console.log(likeDetails)
                likeDetails = JSON.stringify(likeDetails)
                $.ajax({
                    "url": "http://localhost//btcmoon_app/API/users/like-unlike",
                    "type": "POST",
                    "data": likeDetails,
                    success: function (data) {
                        console.log(data);
                    }, error: function (err) {
                        console.log(err);
                    }
                })

                e.target.style.color = 'red'
            } else {

                let likeDetails = {
                    userid: userData.id,
                    post_id,
                    jwt,
                    action: 'unlike'
                }
                console.log(likeDetails)
                likeDetails = JSON.stringify(likeDetails)

                $.ajax({
                    "url": "http://localhost//btcmoon_app/API/users/like-unlike",
                    "type": "POST",
                    "data": likeDetails,
                    success: function (data) {
                        console.log(data);
                    }, error: function (err) {
                        console.log(err);
                    }
                })
                e.target.style.color = 'gray'
            }


        })
    }, error: function (err) {
        console.log(err);
    }
})



// COmment section **************************
let appendComment = document.getElementById('appendComment')
document.getElementById('createComment').addEventListener('click', e => {
    let commentVal = document.getElementById('commentText')

    let commentData = {
        jwt,
        post_id,
        userid: userData.id,
        user_comment: commentVal.value,
        action: "add"
    }

    commentData = JSON.stringify(commentData)
    let commentHtml

    $.ajax({
        "url": "http://localhost//btcmoon_app/API/users/comment",
        "type": "POST",
        "data": commentData,
        success: function (data) {
            // @ append for success message
            commentHtml = `<div class="comments_div">
            <img src="/images/img5.png" alt="">
            <div>
                <h4>${userData.first_name} ${userData.surname} <span style="font-weight: 300; font-size: 10px">now</span></h4>
                <p>${commentVal.value}</p>
                <div class="comment_reaction">
                    <div><i class="fa fa-heart"></i> <span>0</span></div>
                </div>
            </div>
        </div>`
            appendComment.insertAdjacentHTML('afterbegin', commentHtml)

        }, error: function (err) {
            console.log(err);
        }
    })


    console.log(commentData)
})

// Load all the comment by default
let getCommentData = JSON.stringify({
    post_id,
    jwt
})

$.ajax({
    "url": "http://localhost//btcmoon_app/API/users/post-comments",
    "type": "POST",
    "data": getCommentData,
    success: function (data) {
        console.log(data);

        data.map(val => {
            let imageURL = '' 
            if (val.image == "") {
                imageURL = '/images/avatar.png'
            }
            else {
                imageURL = `http://localhost//btcmoon_app/${val.image}`
            }

            appendComment.innerHTML +=
                `<div class="comments_div">
        <a href="/templates/profile.html?userId=${val.author_id}">

        <img src="${imageURL}" alt="">
        </a>
            <div>
            <a href="/templates/profile.html?userId=${val.author_id}">
                <h4>${val.author_name} <span style="font-weight: 300; font-size: 10px">${val.time}</span></h4>
                <p>${val.comment}</p>
                </a>
                <div class="comment_reaction">
                    <div><i class="fa fa-heart"></i> <span>0</span> 
                    <span class="commentOptionSpan">
                        <i id="deleteCommentBtn" class="fa fa-trash"></i>
                        <p style="display: none" id="commentId">${val.comment_id}</p>
                        <p style="display: none" id="commentId">${val.comment_id}</p>
                        <p style="display: none" id="commentOwnerId">${val.author_id}</p>
                        
                    </span>
                     </div>                    
                </div>
            </div>
        </div>`



            let deleteCommentBtn = document.querySelectorAll('#deleteCommentBtn')
            for (i = 0; i < deleteCommentBtn.length; i++) {
                deleteCommentBtn[i].addEventListener('click', e => {
                    console.log('clicked')

                    let confirmDel = confirm('Are you sure u want to delete this comment?')
                    if (!confirmDel) {
                        return
                    }

                    let commentId = e.target.parentElement.children[1].textContent
                    let sendCommentData = {
                        jwt: jwt,
                        comment_id: commentId,
                        userid: userData.id,
                        action: 'delete'
                    }

                    sendCommentData = JSON.stringify(sendCommentData)
                    $.ajax({
                        "url": `http://localhost//btcmoon_app/API/users/comment`,
                        "type": "POST",
                        "data": sendCommentData,
                        success: function (data) {
                            console.log(data)
                            location.reload()

                        }, error: function (err) {
                            console.log(err);
                        }
                    })

                })
            }


            let commentOwnerId = document.querySelectorAll('#commentOwnerId')
            commentOwnerId.forEach(val => {
                if (val.textContent !== userData.id) {
                    val.parentElement.style.display = 'none'
                }
            })


        })

    }, error: function (err) {
        console.log(err);
    }
})

