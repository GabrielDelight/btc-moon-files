let firstname = document.getElementById('firstname')
let surname = document.getElementById('lastname')
let username = document.getElementById('username')
let email = document.getElementById('email')
let password = document.getElementById('password')

document.getElementById('signupBtn').addEventListener('click', e => {
    e.preventDefault()
    if (firstname.value.trim() == '' ||
        surname.value.trim() == '' ||
        username.value.trim() == '' ||
        email.value.trim() == '' ||
        password.value.trim() == '') {
            return alert('All fields are required')
    }
    console.log('Clicked');
    //var btcmoon_address = $('#btcmoon_addr').val();
    var data = {
        btcmoon_address: "0xf562A7708b637e9D10D154F8127266A181719b34",
        first_name: firstname.value,
        surname: surname.value,
        password: password.value,
        email: email.value,
        ip_address: "125.23.3",
        username: username.value
    };

    var data_stringify = JSON.stringify(data);
    $.ajax({
        "url": "http://localhost//btcmoon_app/api/users/register",
        "type": "POST",
        "data": data_stringify,
        success: function (data) {
            console.log(data);

        }, error: function (err) {
            console.log(err);
        }
    })


});