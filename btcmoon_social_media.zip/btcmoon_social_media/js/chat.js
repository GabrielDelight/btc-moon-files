var url = new URLSearchParams(location.search);
var receiverName = url.get("name");
var receiverId = url.get("userid");
var receiverUserName = url.get("uname");

var time = new Date().toLocaleString;
document.getElementById("receiver-name").innerHTML = receiverName;

let x = document.querySelector('.message_body')
x.scrollTop += 994000

  function scrollChatUp() {
    let x = document.querySelector('.message_body')
    x.scrollTop += 994000
  }
  

document.getElementById("sendChat").addEventListener("click", (e) => {
  console.log("Clicked");
  e.preventDefault();


  var message = document.getElementById("message").value;
  if (message == "") {
    alert("Write a message");
    return false;
  }

  var jwt = getJWTCookie("jwt");
  Userdata = getLocalStorage("userData");
  console.log(Userdata);
  //return false;
  //var btcmoon_address = $('#btcmoon_addr').val();
  var data = {
    sender_name: Userdata.first_name + " " + Userdata.surname,
    receiver_name: receiverName,
    sender_username: Userdata.username,
    receiver_username: receiverUserName,
    time: time,
    message: message,
    sender_id: Userdata.id,
    receiver_id: receiverId,
    jwt: jwt,
  };
  document.getElementById("message").value = "";

  var data_stringify = JSON.stringify(data);
  $.ajax({
    url: "http://localhost//btcmoon_app/API/users/insert-chat",
    type: "POST",
    data: data_stringify,
    success: function (data) {
      console.log(data);
      var res = $.trim(data.message);
      if (res == "Message sent successfully") {
        $("#response").text("Message sent").fadeOut(1000);
      } else {
        alert(data.message);
      }
    },
    error: function (err) {
      console.log(err);
    },
  });
});

var howManyrequest = 0;
var chat_length = 0;
setInterval(() => {
  var jwt = getJWTCookie("jwt");
  Userdata = getLocalStorage("userData");
  // console.log(Userdata);
  //return false;
  //var btcmoon_address = $('#btcmoon_addr').val();
  var data = {
    sender_id: Userdata.id,
    receiver_id: receiverId,
    jwt: jwt,
  };
  var data_stringify = JSON.stringify(data);
  $.ajax({
    url: "http://localhost//btcmoon_app/API/users/user_chats",
    type: "POST",
    data: data_stringify,
    success: function (data) {
      var chats = document.querySelector(".message_body");
      if (howManyrequest == 0) {
        howManyrequest = 1;
        console.log(data);
        chat_length = chat_length + data.length;
        for (var i = 0; i < data.length; i++) {
          if (data[i].your_chat == "true") {
            chats.innerHTML += `
             <div class="right_chat">
                <p>${data[i].message}</p>
            </div>
            `;
          } else {
            chats.innerHTML += `
             <div class="left_chat">
                <p>${data[i].message}</p>
            </div>
            `;
          }
          scrollChatUp();
        }
      } else {
        if (chat_length == data.length) {
          //no chat
        } else {
          //new chat
          chat_length = data.length;
          console.log(data);
          chats.innerHTML = '';
          
          for (var i = 0; i < data.length; i++) {
            if (data[i].your_chat == "true") {
              chats.innerHTML += `
             <div class="right_chat">
                <p>${data[i].message}</p>
            </div>
            `;
            // scrollChatUp();
            // window.scrollTop("",document.body);
            } else {
              chats.innerHTML += `
             <div class="left_chat">
                <p>${data[i].message}</p>
            </div>
            `;
            // scrollChatUp();
            }
            scrollChatUp();
          }
        }
      }
    },
    error: function (err) {
      console.log(err);
    },
  });
}, 3000);
