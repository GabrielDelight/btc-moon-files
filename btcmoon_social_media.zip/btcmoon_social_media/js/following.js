var jwt = getJWTCookie("jwt").toString();
let userData = JSON.parse(localStorage.getItem('userData'))

var url = new URLSearchParams(location.search);
var paramsid = url.get("userId");

// Getting all followers
let data_stringify = {
    jwt,
    userid: paramsid,
    action: "following",
}

data_stringify = JSON.stringify(data_stringify)
let appendFoollowings = document.getElementById('appendFoollowings')

$.ajax({
    "url": "http://localhost//btcmoon_app/API/users/followers_following",
    "type": "POST",
    "data": data_stringify,
    success: function (data) {
        console.log(data);
        data.map(val => {
            appendFoollowings.innerHTML +=
                `<div class="has_relative_user">
                <a href="/templates/profile.html?userId=${val.userid}" class="users_list">
        <img src="http://localhost//btcmoon_app/${val.image}" alt="">
        <div>
            <h4>${val.name}</h4>
            <p>@${val.username}</p>
            </div>
        </a>
        <div class="follow_div">
            <button id="followingBtnClick" class="followingBtn">Unfollow</button>
            <p style="display: none" id="folloingId">${val.userid}</p>
            <p style="display: none" id="followers">${val.followers}</p>
            <p style="display: none" id="following">${val.following}</p>
        </div>
        </div>`

            // Hide my own list 
            let folloingId = document.querySelectorAll('#folloingId')
            for (i = 0; i < folloingId.length; i++) {
                if (folloingId[i].textContent == userData.id) {
                    folloingId[i].parentElement.parentElement.style.display = 'none'
                }
            }

            // check if am following that user
            let followers = document.querySelectorAll('#followers')
            for (i = 0; i < followers.length; i++) {
                if (followers[i].textContent.includes(userData.id)) {
                    followers[i].parentElement.children[0].classList = 'followingBtn'
                }
            }

            let followingBtn = document.querySelectorAll('#followingBtnClick')

            for (i = 0; i < followingBtn.length; i++) {
                followingBtn[i].addEventListener('click', (e) => {
                    // @ Follow a user
                    if (e.target.textContent == 'Unfollow') {
                        e.target.classList = 'followBtn'
                        e.target.textContent = 'Follow'
                        let unfollowid = e.target.parentElement.children[1].textContent

                        let unfollowDetails = {
                            jwt: jwt,
                            userid: userData.id,
                            unfollow_id: unfollowid
                        }
                        unfollowDetails = JSON.stringify(unfollowDetails)

                        console.log('Un following')

                        $.ajax({
                            "url": `http://localhost//btcmoon_app/API/users/unfollow`,
                            "type": "POST",
                            "data": unfollowDetails,
                            success: function (data) {
                                console.log(data)

                            }, error: function (err) {
                                console.log(err);
                            }
                        })
                        console.log('Unfollow')

                    } else {
                        // @ Unfollow a user
                        e.target.classList = 'followingBtn'
                        e.target.textContent = 'Unfollow'

                        let followid = e.target.parentElement.children[1].textContent

                        let followDetails = {
                            jwt: jwt,
                            userid: userData.id,
                            follow_id: followid
                        }
                        followDetails = JSON.stringify(followDetails)
                        console.log('FOllowing')
                        $.ajax({
                            "url": `http://localhost//btcmoon_app/API/users/follow`,
                            "type": "POST",
                            "data": followDetails,
                            success: function (data) {
                                console.log(data)

                            }, error: function (err) {
                                console.log(err);
                            }
                        })

                    }
                })
            }
        })

    }, error: function (err) {
        console.log(err);
    }
})
