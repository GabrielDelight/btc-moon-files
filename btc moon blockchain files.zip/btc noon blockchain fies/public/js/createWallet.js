let createBtn = document.getElementById('createBtn')
let email = document.getElementById('email')
let description = document.getElementById('description')
let password = document.getElementById('password')

createBtn.addEventListener('click', e => {
 console.log('Clicked')
 var token = null;
 var settings = {
   "url": "https://cors-anywhere.herokuapp.com/https://login-staging.arkane.network/auth/realms/Arkane/protocol/openid-connect/token",
   "method": "POST",
   "timeout": 0,
   "crossDomain": true,
   "headers": {
     "Content-Type": "application/x-www-form-urlencoded"
   },
   "data": {
     "grant_type": "client_credentials",
     "client_id": "Testaccount-capsule",
     "client_secret": "82c19251-1753-44f5-ae76-93438d3628de"
   }
 };
 $.ajax(settings).done(function (response) {
   // console.log(response);
   token = response.access_token;

   // Send call inside the first call
   var createSettings = {
     "url": "https://cors-anywhere.herokuapp.com/https://api-staging.arkane.network/api/wallets",
     "method": "POST",
     "timeout": 0,
     "headers": {
       "Content-Type": "application/json",
       "Authorization": "Bearer " + token
     },
     "data": JSON.stringify({
       "pincode": password.value,
       "description": description.value,
       "identifier": "type=unrecoverable",
       "secretType": "BSC",
       "walletType": "WHITE_LABEL"
     }),
   };

   $.ajax(createSettings).done(function (response) {
     console.log('Wallet created successfully')
     console.log(response);
    let data = {
      walletId: response.result.id,
      walletAddress: response.result.address,
      pincode: password.value
    }    
     localStorage.setItem('wallet', JSON.stringify(data))
    //  Redirect to wallet page
    location.href = '../templates/index.html'
   });

 });

})


